Public Class MandatoryFieldResult
    Public Property Value As String
    Public Property Confidence As Double
End Class